package com.company;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Main {

    public static void main(String[] args) {
        ArrayList<Person> people = new ArrayList<>();
        while (true) {
            Person p = new Person(
                    randomString(),
                    randomString(),
                    ThreadLocalRandom.current().nextInt(1900, 2022),
                    randomString()
            );
            people.add(p);
            System.out.println(p.toString());
        }
    }

    public static String randomString() {
        int leftLimit = 97;
        int rightLimit = 122;
        int targetStringLength = 10;
        Random random = new Random();
        StringBuilder buffer = new StringBuilder(targetStringLength);
        for (int i = 0; i < targetStringLength; i++) {
            int randomLimitedInt = leftLimit + (int)
                    (random.nextFloat() * (rightLimit - leftLimit + 1));
            buffer.append((char) randomLimitedInt);
        }
        return buffer.toString();
    }
}


