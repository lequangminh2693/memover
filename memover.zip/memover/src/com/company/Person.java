package com.company;

public class Person {
    private String fullname;
    private String address;
    private int yearOfBirth;
    private String bio;

    public Person(String fullname, String address, int yearOfBirth, String bio) {
        this.fullname = fullname;
        this.address = address;
        this.yearOfBirth = yearOfBirth;
        this.bio = bio;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getYearOfBirth() {
        return yearOfBirth;
    }

    public void setYearOfBirth(int yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    @Override
    public String toString() {
        return "Person{" +
                "fullname='" + fullname + '\'' +
                ", address='" + address + '\'' +
                ", yearOfBirth=" + yearOfBirth +
                ", bio='" + bio + '\'' +
                '}';
    }
}
